#ifndef PRINTS_E_ERROS_H
    #define PRINTS_E_ERROS_H
    #include <stdio.h>
    #include <stdlib.h>



    void ErroPadrao(void);
    void ErroAlocacao(void); //Imprime e exit(1)
    void ErroDesalocar(void);
    void ErroArquivo(void);
    void ErroRegistro(void);
    
#endif